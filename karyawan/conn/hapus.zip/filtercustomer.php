<?php 
    $tglawal = $_POST['tanggalawal'];
    $tglakhir = $_POST['tanggalakhir'];
    
    
    
    echo"<script>alert('Pencarian berhasil');window.location='../reportcustomer.php?tglawal=$tglawal&tglakhir=$tglakhir'</script>";
?>